const express = require('express');
const mongoose = require('mongoose');
const User = require('./Model/user');
const Review = require('./Model/review');
const Comment = require('./Model/comment');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb+srv://julliantalino:Suicidalneko1@nekokami.hcwrogz.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'homepage.html'));
});

app.get('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.password !== password) {
      return res.status(401).json({ message: 'Incorrect password' });
    }

    return res.status(200).json({ message: 'Login successful', user });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});

app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  try {
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    const newUser = new User({ username, email, password });
    await newUser.save();

    return res.status(201).json({ message: 'User created successfully', user: newUser });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});

app.post('/editprofile', async (req, res) => {
  const { userId, newUsername, newEmail } = req.body;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (newUsername) {
      user.username = newUsername;
    }

    if (newEmail) {
      user.email = newEmail;
    }

    await user.save();

    return res.status(200).json({ message: 'Profile updated successfully', user });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});

app.get('/establishments', async (req, res) => {
  try {

    const establishments = await Establishment.find();

    if (!establishments || establishments.length === 0) {
      return res.status(404).json({ message: 'No establishments found' });
    }

    return res.status(200).json({ establishments });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});


app.get('/establishmentowner/:userId', async (req, res) => {
  const ownerId = req.params.userId;

  try {

    const establishments = await Review.find({ reviewer: ownerId }).populate('establishment');

    if (!establishments || establishments.length === 0) {
      return res.status(404).json({ message: 'No establishments found for this owner' });
    }

    return res.status(200).json({ establishments });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});


app.get('/establishmentreviews/:establishmentId', async (req, res) => {
  const establishmentId = req.params.establishmentId;

  try {

    const reviews = await Review.find({ establishment: establishmentId });

    if (!reviews || reviews.length === 0) {
      return res.status(404).json({ message: 'No reviews found for this establishment' });
    }

    return res.status(200).json({ reviews });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});


app.get('/userprofile/:userId', async (req, res) => {
  const userId = req.params.userId;

  try {

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User profile not found' });
    }

    return res.status(200).json({ user });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server Error' });
  }
});


app.get('/aboutus', (req, res) => {
  res.sendFile(path.join(__dirname, 'aboutus.html'));
});


app.post('/createreview', async (req, res) => {
  try {
    const { title, content, rating, reviewerId } = req.body; 

    const newReview = new Review({
      title,
      content,
      rating,
      reviewer: reviewerId, 
      comments: [],
      createdAt: new Date(),
    });

    await newReview.save();

    res.redirect('/'); 
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});


app.post('/reviewdetails', async (req, res) => {
  try {
    const { reviewId } = req.body;

    const review = await Review.findById(reviewId)
      .populate('reviewer') 
      .populate({
        path: 'comments', 
        populate: { path: 'author' } 
      });

    if (!review) {
      return res.status(404).send('Review not found');
    }

    res.json(review);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});


app.get('/searchresults', async (req, res) => {
  try {
    const { query } = req.query; 

    const searchResults = await Review.find({
      $or: [
        { title: { $regex: query, $options: 'i' } }, 
        { content: { $regex: query, $options: 'i' } } 
      ]
    }).populate('reviewer'); 

    res.json(searchResults);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});



app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
