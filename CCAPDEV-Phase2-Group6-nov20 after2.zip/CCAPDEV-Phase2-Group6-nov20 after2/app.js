const express = require('express');
const mongoose = require('mongoose');
const fs = require('fs').promises;
const path = require('path');
const session = require('express-session');  // Add this line
const bcrypt = require('bcrypt'); 
const app = express();
const port = 3000;
const router = express.Router();
const User = require('./Model/user');
const Review = require('./Model/review');
const Comment = require('./Model/comment');
const Establishment = require('./Model/establishment');

mongoose.connect('mongodb+srv://julliantalino:Suicidalneko1@nekokami.hcwrogz.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDB connected');
  })
  .catch((err) => {
    console.error('MongoDB connection error', err);
  });

// Middleware for parsing JSON and handling URL-encoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session middleware
app.use(session({
  secret: 'your-secret-key',
  resave: true,
  saveUninitialized: true
}));

// Serve static files (HTML, CSS, images) from a directory
app.use(express.static('public'));

// Routes
app.use('/', router);

// Read the contents of the styles.css file
const readStylesFile = async () => {
  try {
    const filePath = path.join(__dirname, 'styles.css');
    const stylesContent = await fs.readFile(filePath, 'utf-8');
    return stylesContent;
  } catch (error) {
    console.error(error);
    return ''; // Return an empty string if there's an error reading the file
  }
};

// Homepage route
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/homepage.html');
});

// Home route
router.get('/homepage.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'homepage.html'));
});

// login route
router.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Login route (POST method)
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
      const user = await User.findOne({ username });

      if (!user) {
          return res.status(404).send('User not found');
      }

      // Compare passwords
      if (user.password !== password) {
          return res.status(401).send('Invalid password');
      }

      // Successful login, set up the session or token for authentication
      req.session.userId = user._id; // Assuming session-based authentication

      // Redirect to user's profile or any other page
      res.redirect(`/userprofile/${user._id}`);
  } catch (error) {
      res.status(500).send('An error occurred during login');
  }
});

// Register route
router.get('/register.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'register.html'));
});

// Registration route
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  try {
    // Check if the username or email is already taken
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      return res.status(400).send('Username or email is already taken');
    }

    // Hash the password before saving to the database
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user instance using the User model
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
    });

    // Save the new user to the database
    await newUser.save();

    // Set up the session or token for authentication
    req.session.userId = newUser._id;

    // Redirect to user's profile or any other page
    res.redirect(`/userprofile/${newUser._id}`);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error during registration');
  }
});

// Createreview route
router.get('/createreview.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'createreview.html'));
});

// Create review (POST method)
router.post('/createreview', async (req, res) => {
  const { establishment, reviewTitle, reviewBody, rating, media } = req.body;

  try {
      // Validate input data
      if (!establishment || !reviewTitle || !reviewBody || !rating) {
          return res.status(400).send('All fields are required');
      }

      // Check if user is logged in (user ID is stored in the session)
      if (!req.session.userId) {
          return res.status(401).send('User not authenticated');
      }

      // Use the logged-in user's ID as the reviewer
      const reviewerId = req.session.userId;

      // Create a new review instance using the Review model
      const newReview = new Review({
          establishment,
          title: reviewTitle,
          content: reviewBody,
          rating,
          reviewer: reviewerId,
      });

      // Save the new review to the database
      await newReview.save();

      // Redirect or render a page indicating success
      res.redirect('/success'); // Redirect to a success page or other route
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error creating review');
  }
});





// ...

// User profile route
router.get('/userprofile/:userId', async (req, res) => {
  const userId = req.params.userId;

  try {
    // Retrieve user profile by user ID from the database
    const userProfile = await User.findById(userId);

    if (!userProfile) {
      return res.status(404).send('User profile not found');
    }

    // Render the user profile page with user details
    // Adjust the rendering logic according to your template engine or frontend framework
    res.render('userprofile', { userProfile });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error retrieving user profile');
  }
});

// About Us route
router.get('/aboutus.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'aboutus.html'));
});

// Establishments route
router.get('/establishments.html', (req, res) => {
  Establishment.find({}, (err, establishments) => {
      if (err) {
          console.error(err);
          res.status(500).send('Internal Server Error');
      } else {
          res.render('establishments', { establishments });
      }
  });
});



// Write a comment route
app.post('/establishmentower', async(req, res) => {
  const reviewId = req.params.reviewId;
  const { text, authorId } = req.body; // Assuming 'text' and 'authorId' come from the form

  try {
      // Find the review by its ID
      const review = await Review.findById(reviewId);

      if (!review) {
          return res.status(404).send('Review not found');
      }

      // Create a new comment using the Comment model
      const newComment = new Comment({
          text,
          author: authorId, // Assuming authorId is the ID of the logged-in user
          review: reviewId,
      });

      // Save the new comment to the database
      await newComment.save();

      // Add the comment to the review's comments array
      review.comments.push(newComment);
      await review.save();

      // Redirect or respond with a success message
      res.redirect(`/review/${reviewId}`); // Redirect to the review page or other route
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error adding comment');
  }
});

// editprofile route
router.get('/editprofile.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'editprofile.html'));
});

// Handle profile update (POST request)
router.post('/editprofile', async (req, res) => {
  const userId = req.user.id; // Assuming you have the user ID from authentication middleware
  const { username, email } = req.body; // Assuming 'username' and 'email' come from the form

  try {
      // Find the user by ID and update the profile information
      await User.findByIdAndUpdate(userId, { username, email });

      // Redirect to the user's profile page or another relevant route
      res.redirect(`/profile/${userId}`);
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error updating profile');
  }
});

// Establishment Reviews route
router.get('/establishmentreviews/:establishmentId', async (req, res) => {
  const establishmentId = req.params.establishmentId;

  try {
      // Fetch the specific establishment
      const establishment = await Establishment.findById(establishmentId);

      if (!establishment) {
          return res.status(404).send('Establishment not found');
      }

      // Fetch reviews related to the establishment
      const reviews = await Review.find({ establishment: establishmentId }).populate('reviewer');

      // Render the establishment reviews page with the fetched data
      res.render('establishment-reviews', { establishment, reviews });
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error fetching establishment reviews');
  }
});

// full- review route
router.get('/full-review.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'full-review.html'));
});

// Render review details including associated comments
router.get('/reviewdetails/:reviewId', async (req, res) => {
  const reviewId = req.params.reviewId;

  try {
      // Fetch the specific review
      const review = await Review.findById(reviewId).populate('reviewer').populate('comments');

      if (!review) {
          return res.status(404).send('Review not found');
      }

      // Render the review details page with the fetched review and its comments
      res.render('review-details', { review });
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error fetching review details');
  }
});

// userprofile route
router.get('/userprofile.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'userprofile.html'));
});

// Route to display search results
router.get('/searchresults', async (req, res) => {
  const searchQuery = req.query.q; // Assuming the search query is sent as a query parameter 'q'

  try {
      // Fetch establishments based on the search query
      const establishments = await Establishment.find({
          $or: [
              { name: { $regex: searchQuery, $options: 'i' } }, // Searching for establishments by name
              { description: { $regex: searchQuery, $options: 'i' } } // Searching for establishments by description
          ]
      });

      // Render the search results page with the fetched establishments
      res.render('search-results', { establishments, searchQuery });
  } catch (err) {
      // Handle any potential errors
      console.error(err);
      res.status(500).send('Error fetching search results');
  }
});

module.exports = router;

// Listen for server connections
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
