const express = require('express');
const mongoose = require('mongoose');
const User = require('./Model/user');
const Review = require('./Model/review');
const Comment = require('./Model/comment');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb+srv://julliantalino:Suicidalneko1@nekokami.hcwrogz.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

app.get('/', async (req, res) => {
  try {
    // Fetch data from the database
    const users = await User.find().limit(5);
    const reviews = await Review.find().limit(5);
    const comments = await Comment.find().limit(5);

    // Create HTML content dynamically based on the retrieved data
    const htmlContent = `
      <html lang="en">
      <head>
        <!-- Add your head content here -->
      </head>
      <body>
        <section>
          <h2>Users</h2>
          <pre>${JSON.stringify(users, null, 2)}</pre>
        </section>
        <section>
          <h2>Reviews</h2>
          <pre>${JSON.stringify(reviews, null, 2)}</pre>
        </section>
        <section>
          <h2>Comments</h2>
          <pre>${JSON.stringify(comments, null, 2)}</pre>
        </section>
      </body>
      </html>
    `;

    // Send the dynamically generated HTML content as the response
    res.send(htmlContent);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
