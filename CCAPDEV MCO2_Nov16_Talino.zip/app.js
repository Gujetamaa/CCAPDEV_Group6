const express = require('express');
const mongoose = require('mongoose');
const User = require('./Model/user');
const Review = require('./Model/review');
const Comment = require('./Model/comment');
const path = require('path'); // Add this line for path module

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb+srv://julliantalino:Suicidalneko1@nekokami.hcwrogz.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

app.get('/', async (req, res) => {
  try {
    // Fetch sample data from the database
    const users = await User.find().limit(5);
    const reviews = await Review.find().limit(5);
    const comments = await Comment.find().limit(5);

    // Render HTML page with the formatted data
    res.sendFile(path.join(__dirname, 'index.html'), {
      users,
      reviews,
      comments,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
