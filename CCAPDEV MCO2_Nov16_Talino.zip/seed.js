const express = require('express');
const mongoose = require('mongoose');
const User = require('./Model/user');
const Review = require('./Model/review');
const Comment = require('./Model/comment');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb+srv://julliantalino:Suicidalneko1@nekokami.hcwrogz.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });

app.get('/', async (req, res) => {
  try {
    // Fetch sample data from the database
    const users = await User.find().limit(5);

    // Create an array to store the formatted data for response
    const formattedData = [];

    // Iterate through each user
    for (const user of users) {
      // Fetch reviews for the current user
      const reviews = await Review.find({ reviewer: user._id }).limit(5);

      // Create an array to store the formatted reviews for the current user
      const formattedReviews = [];

      // Iterate through each review for the current user
      for (const review of reviews) {
        // Fetch comments for the current review
        const comments = await Comment.find({ review: review._id }).limit(5);

        // Format the review data
        const formattedReview = {
          title: review.title,
          rating: review.rating,
          content: review.content,
          comments: comments.map(comment => ({ text: comment.text })),
        };

        // Push the formatted review to the array
        formattedReviews.push(formattedReview);
      }

      // Format the user data
      const formattedUser = {
        username: user.username,
        email: user.email,
        reviews: formattedReviews,
      };

      // Push the formatted user data to the array
      formattedData.push(formattedUser);
    }

    // Render HTML page with the formatted data
    res.sendFile(path.join(__dirname, 'index.html'), { data: formattedData });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
